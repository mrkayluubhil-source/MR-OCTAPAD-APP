# MR OCTAPAD — MR KAYLUU MOBILE OCTAPAD (Native Android)

## Build & Install APK Instructions

### Option 1: Android Studio (Recommended)
1. Download or copy the `android-project` directory to your computer.
2. Open **Android Studio** (Ladybug / Meerkat or newer with JDK 17).
3. Choose **File > Open...** and select the `android-project` folder.
4. Wait for Gradle Sync to finish downloading Android SDK 35 & Jetpack Compose dependencies.
5. Connect your Android phone via USB (with **Developer Options > USB Debugging** enabled), or select a landscape Android Emulator.
6. Click **Run > Run 'app'** or **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

### Option 2: Command Line (Gradle + ADB)
1. Ensure Android SDK (Platform 35, Build Tools 35.0.0) and JDK 17 are installed and `ANDROID_HOME` is set.
2. From inside `android-project/`:
   ```bash
   gradle wrapper
   ./gradlew assembleDebug
   ```
3. The compiled APK will be created at:
   `app/build/outputs/apk/debug/app-debug.apk`
4. Install directly to a connected Android phone:
   ```bash
   adb install -r app/build/outputs/apk/debug/app-debug.apk
   ```

## Hardware & Physical Device Notes
- **Low-Latency Audio**: Uses `AudioTrack` (`PERFORMANCE_MODE_LOW_LATENCY` on Android 8.0+) with a 24-voice real-time float DSP mixer, 3-band biquad EQ, and Schroeder reverb / echo / delay.
- **USB & Bluetooth MIDI**: Uses `android.media.midi.MidiManager`. Requires a physical Android device with USB OTG adapter or paired Bluetooth LE MIDI hardware to verify external Note In / Note Out.
- **500 Patch Slots & Bundled Samples**: Ships 18 real 16-bit 44.1kHz PCM `.wav` drum & Indian percussion samples in `app/src/main/res/raw/` mapped across 500 editable patch slots (`001`–`500`) in 15 categories, plus SAF WAV/MP3/OGG custom audio import.
