package com.mrkayluu.mroctapad

import android.content.Context
import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class PadConfig(
    val padIndex: Int,
    val sampleKey: String,
    val sampleName: String,
    val volume: Float = 0.9f,
    val pitch: Float = 1.0f,
    val midiNote: Int = 36 + padIndex,
    val customSoundId: String? = null
)

data class PatchSlot(
    val number: Int,
    val name: String,
    val category: String,
    val pads: List<PadConfig>,
    val id: String = "slot_$number",
    val isImported: Boolean = false,
    val sourcePackName: String? = null,
    val importedAtMs: Long = 0L
)

data class DrumKit(
    val id: String,
    val name: String,
    val isFavorite: Boolean = false,
    val pads: List<PadConfig>
)

data class EffectsSettings(
    val masterVolume: Float = 0.85f,
    val bassDb: Float = 0f,
    val trebleDb: Float = 0f,
    val pitchMultiplier: Float = 1.0f,
    val echoMix: Float = 0.0f,
    val delayMix: Float = 0.0f,
    val reverbMix: Float = 0.12f
)

data class EqSettings(
    val enabled: Boolean = true,
    val bassFreqHz: Float = 110f,
    val bassGainDb: Float = 0f,
    val midFreqHz: Float = 1000f,
    val midGainDb: Float = 0f,
    val trebleFreqHz: Float = 6500f,
    val trebleGainDb: Float = 0f
)

data class MidiSettings(
    val channel: Int = 10,
    val velocityScale: Float = 1.0f,
    val midiOutEnabled: Boolean = true,
    val midiInEnabled: Boolean = true,
    val padNotes: List<Int> = listOf(36, 38, 42, 46, 45, 48, 49, 39)
)

data class QualitySettings(
    val preferredSampleRate: Int = 44100,
    val bufferFramesMultiplier: Int = 2,
    val lowLatencyPreferred: Boolean = true,
    val preferredOutputDeviceId: Int = -1
)

data class ImportedSound(
    val id: String,
    val displayName: String,
    val fileName: String,
    val filePath: String = "",
    val sourceUri: String = "",
    val mimeType: String,
    val durationMs: Long
)

data class RecordedEvent(
    val timestampMs: Long,
    val padIndex: Int,
    val velocity: Float,
    val sampleKey: String,
    val customSoundId: String?,
    val midiNote: Int
)

data class PerformanceRecording(
    val id: String,
    val name: String,
    val createdAtMs: Long,
    val durationMs: Long,
    val patchNumber: Int,
    val events: List<RecordedEvent>
)

class StorageManager(private val context: Context) {

    private val prefs: SharedPreferences =
        context.getSharedPreferences("mr_octapad_prefs", Context.MODE_PRIVATE)

    val importedSoundsDir: File by lazy {
        File(context.filesDir, "imported_sounds").apply { mkdirs() }
    }

    val importedPacksDir: File by lazy {
        File(context.filesDir, "imported_packs").apply { mkdirs() }
    }

    private val patchesFile: File get() = File(context.filesDir, "patches_v1.json")
    private val importedPatchesFile: File get() = File(context.filesDir, "imported_patches_v1.json")
    private val kitsFile: File get() = File(context.filesDir, "kits_v1.json")
    private val importedIndexFile: File get() = File(context.filesDir, "imported_sounds_v1.json")
    private val recordingsFile: File get() = File(context.filesDir, "recordings_v1.json")

    fun saveActivePatchNumber(number: Int) {
        prefs.edit().putInt("active_patch_number", number.coerceAtLeast(1)).apply()
    }

    fun loadActivePatchNumber(): Int = prefs.getInt("active_patch_number", 1).coerceAtLeast(1)

    fun saveEffects(settings: EffectsSettings) {
        prefs.edit()
            .putFloat("fx_master", settings.masterVolume)
            .putFloat("fx_bass", settings.bassDb)
            .putFloat("fx_treble", settings.trebleDb)
            .putFloat("fx_pitch", settings.pitchMultiplier)
            .putFloat("fx_echo", settings.echoMix)
            .putFloat("fx_delay", settings.delayMix)
            .putFloat("fx_reverb", settings.reverbMix)
            .apply()
    }

    fun loadEffects(): EffectsSettings = EffectsSettings(
        masterVolume = prefs.getFloat("fx_master", 0.85f),
        bassDb = prefs.getFloat("fx_bass", 0f),
        trebleDb = prefs.getFloat("fx_treble", 0f),
        pitchMultiplier = prefs.getFloat("fx_pitch", 1.0f),
        echoMix = prefs.getFloat("fx_echo", 0f),
        delayMix = prefs.getFloat("fx_delay", 0f),
        reverbMix = prefs.getFloat("fx_reverb", 0.12f)
    )

    fun saveEq(settings: EqSettings) {
        prefs.edit()
            .putBoolean("eq_enabled", settings.enabled)
            .putFloat("eq_bass_freq", settings.bassFreqHz)
            .putFloat("eq_bass_gain", settings.bassGainDb)
            .putFloat("eq_mid_freq", settings.midFreqHz)
            .putFloat("eq_mid_gain", settings.midGainDb)
            .putFloat("eq_treble_freq", settings.trebleFreqHz)
            .putFloat("eq_treble_gain", settings.trebleGainDb)
            .apply()
    }

    fun loadEq(): EqSettings = EqSettings(
        enabled = prefs.getBoolean("eq_enabled", true),
        bassFreqHz = prefs.getFloat("eq_bass_freq", 110f),
        bassGainDb = prefs.getFloat("eq_bass_gain", 0f),
        midFreqHz = prefs.getFloat("eq_mid_freq", 1000f),
        midGainDb = prefs.getFloat("eq_mid_gain", 0f),
        trebleFreqHz = prefs.getFloat("eq_treble_freq", 6500f),
        trebleGainDb = prefs.getFloat("eq_treble_gain", 0f)
    )

    fun saveMidi(settings: MidiSettings) {
        val notesJson = JSONArray(settings.padNotes).toString()
        prefs.edit()
            .putInt("midi_channel", settings.channel)
            .putFloat("midi_vel_scale", settings.velocityScale)
            .putBoolean("midi_out", settings.midiOutEnabled)
            .putBoolean("midi_in", settings.midiInEnabled)
            .putString("midi_pad_notes", notesJson)
            .apply()
    }

    fun loadMidi(): MidiSettings {
        val defaultNotes = listOf(36, 38, 42, 46, 45, 48, 49, 39)
        val raw = prefs.getString("midi_pad_notes", null)
        val parsed = if (raw != null) {
            try {
                val arr = JSONArray(raw)
                (0 until 8).map { i -> if (i < arr.length()) arr.getInt(i) else defaultNotes[i] }
            } catch (_: Exception) {
                defaultNotes
            }
        } else {
            defaultNotes
        }
        return MidiSettings(
            channel = prefs.getInt("midi_channel", 10),
            velocityScale = prefs.getFloat("midi_vel_scale", 1.0f),
            midiOutEnabled = prefs.getBoolean("midi_out", true),
            midiInEnabled = prefs.getBoolean("midi_in", true),
            padNotes = parsed
        )
    }

    fun saveQuality(settings: QualitySettings) {
        prefs.edit()
            .putInt("q_sample_rate", settings.preferredSampleRate)
            .putInt("q_buffer_mult", settings.bufferFramesMultiplier)
            .putBoolean("q_low_latency", settings.lowLatencyPreferred)
            .putInt("q_output_id", settings.preferredOutputDeviceId)
            .apply()
    }

    fun loadQuality(): QualitySettings = QualitySettings(
        preferredSampleRate = prefs.getInt("q_sample_rate", 44100),
        bufferFramesMultiplier = prefs.getInt("q_buffer_mult", 2),
        lowLatencyPreferred = prefs.getBoolean("q_low_latency", true),
        preferredOutputDeviceId = prefs.getInt("q_output_id", -1)
    )

    fun saveCustomPatches(overrides: Map<Int, PatchSlot>) {
        val arr = JSONArray()
        overrides.values.sortedBy { it.number }.forEach { patch ->
            arr.put(patchToJson(patch))
        }
        atomicWrite(patchesFile, arr.toString())
    }

    fun loadCustomPatches(): Map<Int, PatchSlot> {
        if (!patchesFile.exists()) return emptyMap()
        return try {
            val arr = JSONArray(patchesFile.readText())
            val map = mutableMapOf<Int, PatchSlot>()
            for (i in 0 until arr.length()) {
                val p = jsonToPatch(arr.getJSONObject(i))
                map[p.number] = p
            }
            map
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun saveImportedPatches(patches: List<PatchSlot>) {
        val arr = JSONArray()
        patches.forEach { patch ->
            arr.put(patchToJson(patch))
        }
        atomicWrite(importedPatchesFile, arr.toString())
    }

    fun loadImportedPatches(): List<PatchSlot> {
        if (!importedPatchesFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(importedPatchesFile.readText())
            (0 until arr.length()).map { i -> jsonToPatch(arr.getJSONObject(i)) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveKits(kits: List<DrumKit>) {
        val arr = JSONArray()
        kits.forEach { kit ->
            val obj = JSONObject()
            obj.put("id", kit.id)
            obj.put("name", kit.name)
            obj.put("isFavorite", kit.isFavorite)
            obj.put("pads", padsToJson(kit.pads))
            arr.put(obj)
        }
        atomicWrite(kitsFile, arr.toString())
    }

    fun loadKits(): List<DrumKit> {
        if (!kitsFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(kitsFile.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                DrumKit(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    isFavorite = obj.optBoolean("isFavorite", false),
                    pads = jsonToPads(obj.getJSONArray("pads"))
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveImportedSounds(sounds: List<ImportedSound>) {
        val arr = JSONArray()
        sounds.forEach { s ->
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("displayName", s.displayName)
            obj.put("fileName", s.fileName)
            obj.put("filePath", s.filePath)
            obj.put("sourceUri", s.sourceUri)
            obj.put("mimeType", s.mimeType)
            obj.put("durationMs", s.durationMs)
            arr.put(obj)
        }
        atomicWrite(importedIndexFile, arr.toString())
    }

    fun loadImportedSounds(): List<ImportedSound> {
        if (!importedIndexFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(importedIndexFile.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                val fname = obj.getString("fileName")
                ImportedSound(
                    id = obj.getString("id"),
                    displayName = obj.getString("displayName"),
                    fileName = fname,
                    filePath = obj.optString("filePath", File(importedSoundsDir, fname).absolutePath),
                    sourceUri = obj.optString("sourceUri", ""),
                    mimeType = obj.optString("mimeType", "audio/wav"),
                    durationMs = obj.optLong("durationMs", 0L)
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    fun saveRecordings(recordings: List<PerformanceRecording>) {
        val arr = JSONArray()
        recordings.forEach { rec ->
            val obj = JSONObject()
            obj.put("id", rec.id)
            obj.put("name", rec.name)
            obj.put("createdAtMs", rec.createdAtMs)
            obj.put("durationMs", rec.durationMs)
            obj.put("patchNumber", rec.patchNumber)
            val evArr = JSONArray()
            rec.events.forEach { ev ->
                val eObj = JSONObject()
                eObj.put("timestampMs", ev.timestampMs)
                eObj.put("padIndex", ev.padIndex)
                eObj.put("velocity", ev.velocity.toDouble())
                eObj.put("sampleKey", ev.sampleKey)
                if (ev.customSoundId != null) eObj.put("customSoundId", ev.customSoundId)
                eObj.put("midiNote", ev.midiNote)
                evArr.put(eObj)
            }
            obj.put("events", evArr)
            arr.put(obj)
        }
        atomicWrite(recordingsFile, arr.toString())
    }

    fun loadRecordings(): List<PerformanceRecording> {
        if (!recordingsFile.exists()) return emptyList()
        return try {
            val arr = JSONArray(recordingsFile.readText())
            (0 until arr.length()).map { i ->
                val obj = arr.getJSONObject(i)
                val evArr = obj.getJSONArray("events")
                val events = (0 until evArr.length()).map { j ->
                    val e = evArr.getJSONObject(j)
                    RecordedEvent(
                        timestampMs = e.getLong("timestampMs"),
                        padIndex = e.getInt("padIndex"),
                        velocity = e.getDouble("velocity").toFloat(),
                        sampleKey = e.getString("sampleKey"),
                        customSoundId = if (e.has("customSoundId") && !e.isNull("customSoundId")) {
                            e.optString("customSoundId").takeIf { it.isNotBlank() && it != "null" }
                        } else null,
                        midiNote = e.optInt("midiNote", 36)
                    )
                }
                PerformanceRecording(
                    id = obj.getString("id"),
                    name = obj.getString("name"),
                    createdAtMs = obj.getLong("createdAtMs"),
                    durationMs = obj.getLong("durationMs"),
                    patchNumber = obj.optInt("patchNumber", 1),
                    events = events
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun patchToJson(patch: PatchSlot): JSONObject {
        val obj = JSONObject()
        obj.put("number", patch.number)
        obj.put("name", patch.name)
        obj.put("category", patch.category)
        obj.put("id", patch.id)
        obj.put("isImported", patch.isImported)
        if (patch.sourcePackName != null) obj.put("sourcePackName", patch.sourcePackName)
        obj.put("importedAtMs", patch.importedAtMs)
        obj.put("pads", padsToJson(patch.pads))
        return obj
    }

    private fun jsonToPatch(obj: JSONObject): PatchSlot {
        val num = obj.getInt("number")
        return PatchSlot(
            number = num,
            name = obj.getString("name"),
            category = obj.getString("category"),
            pads = jsonToPads(obj.getJSONArray("pads")),
            id = obj.optString("id", "slot_$num"),
            isImported = obj.optBoolean("isImported", false),
            sourcePackName = if (obj.has("sourcePackName") && !obj.isNull("sourcePackName")) obj.optString("sourcePackName") else null,
            importedAtMs = obj.optLong("importedAtMs", 0L)
        )
    }

    private fun padsToJson(pads: List<PadConfig>): JSONArray {
        val arr = JSONArray()
        pads.forEach { p ->
            val obj = JSONObject()
            obj.put("padIndex", p.padIndex)
            obj.put("sampleKey", p.sampleKey)
            obj.put("sampleName", p.sampleName)
            obj.put("volume", p.volume.toDouble())
            obj.put("pitch", p.pitch.toDouble())
            obj.put("midiNote", p.midiNote)
            if (p.customSoundId != null) obj.put("customSoundId", p.customSoundId)
            arr.put(obj)
        }
        return arr
    }

    private fun jsonToPads(arr: JSONArray): List<PadConfig> =
        (0 until arr.length()).map { i ->
            val obj = arr.getJSONObject(i)
            PadConfig(
                padIndex = obj.getInt("padIndex"),
                sampleKey = obj.getString("sampleKey"),
                sampleName = obj.getString("sampleName"),
                volume = obj.optDouble("volume", 0.9).toFloat(),
                pitch = obj.optDouble("pitch", 1.0).toFloat(),
                midiNote = obj.optInt("midiNote", 36 + i),
                customSoundId = if (obj.has("customSoundId") && !obj.isNull("customSoundId")) {
                    obj.optString("customSoundId").takeIf { it.isNotBlank() && it != "null" }
                } else null
            )
        }

    private fun atomicWrite(target: File, content: String) {
        val tmp = File(target.parentFile, "${target.name}.tmp")
        tmp.writeText(content)
        if (!tmp.renameTo(target)) {
            target.writeText(content)
            tmp.delete()
        }
    }
}
