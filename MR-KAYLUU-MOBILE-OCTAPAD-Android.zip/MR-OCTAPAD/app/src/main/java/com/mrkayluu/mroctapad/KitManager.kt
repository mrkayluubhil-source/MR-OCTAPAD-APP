package com.mrkayluu.mroctapad

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class KitManager(
    private val storageManager: StorageManager,
    private val patchManager: PatchManager
) {
    private val _kits = MutableStateFlow(storageManager.loadKits())
    val kits: StateFlow<List<DrumKit>> = _kits.asStateFlow()

    fun saveCurrentAsKit(name: String): DrumKit {
        val clean = name.trim().ifEmpty { "Custom Kit ${_kits.value.size + 1}" }.take(32)
        val kit = DrumKit(
            id = "kit_${UUID.randomUUID().toString().take(8)}",
            name = clean,
            isFavorite = false,
            pads = patchManager.activePatch.pads
        )
        val next = listOf(kit) + _kits.value
        _kits.value = next
        storageManager.saveKits(next)
        return kit
    }

    fun loadKitIntoActivePatch(kitId: String) {
        val kit = _kits.value.firstOrNull { it.id == kitId } ?: return
        patchManager.applyPadsToActivePatch(kit.pads)
    }

    fun renameKit(kitId: String, newName: String) {
        val clean = newName.trim().take(32)
        if (clean.isEmpty()) return
        val next = _kits.value.map { if (it.id == kitId) it.copy(name = clean) else it }
        _kits.value = next
        storageManager.saveKits(next)
    }

    fun toggleFavorite(kitId: String) {
        val next = _kits.value.map { if (it.id == kitId) it.copy(isFavorite = !it.isFavorite) else it }
        _kits.value = next
        storageManager.saveKits(next)
    }

    fun deleteKit(kitId: String) {
        val next = _kits.value.filterNot { it.id == kitId }
        _kits.value = next
        storageManager.saveKits(next)
    }

    fun restoreDefaultActivePatch() {
        patchManager.resetPatchToDefault(patchManager.activePatchNumber.value)
    }
}
