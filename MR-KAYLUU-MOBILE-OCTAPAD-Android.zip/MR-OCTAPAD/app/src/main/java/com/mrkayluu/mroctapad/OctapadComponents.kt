package com.mrkayluu.mroctapad

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FastForward
import androidx.compose.material.icons.filled.FastRewind
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.roundToInt
import kotlin.math.sin

@Composable
fun HardwareFunctionButton(
    label: String,
    isActive: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val bgBrush = if (isActive) {
        Brush.verticalGradient(listOf(Color(0xFF1D8BFF), Color(0xFF0D59B8)))
    } else {
        Brush.verticalGradient(listOf(Color(0xFF2D3543), Color(0xFF161B23)))
    }
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(40.dp)
            .shadow(4.dp, RoundedCornerShape(7.dp))
            .clip(RoundedCornerShape(7.dp))
            .background(bgBrush)
            .border(
                width = 1.2.dp,
                color = if (isActive) Color(0xFF7DD3FC) else Color(0xFF424E61),
                shape = RoundedCornerShape(7.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 4.dp)
    ) {
        Text(
            text = label,
            color = if (isActive) Color.White else Color(0xFFE2E8F0),
            fontSize = 10.sp,
            fontWeight = FontWeight.ExtraBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

@Composable
fun RotaryKnob(
    label: String,
    value: Float,
    minValue: Float,
    maxValue: Float,
    displayValue: String,
    onValueChange: (Float) -> Unit,
    knobSize: Dp = 64.dp,
    modifier: Modifier = Modifier
) {
    val normalized = ((value - minValue) / (maxValue - minValue)).coerceIn(0f, 1f)
    var currentNorm by remember(value) { mutableFloatStateOf(normalized) }

    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = modifier
    ) {
        Text(
            text = label,
            color = Color(0xFFE2E8F0),
            fontSize = 12.sp,
            fontWeight = FontWeight.SemiBold,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(4.dp))
        Box(
            contentAlignment = Alignment.Center,
            modifier = Modifier
                .size(knobSize)
                .pointerInput(minValue, maxValue) {
                    detectDragGestures { change, dragAmount ->
                        change.consume()
                        val delta = (-dragAmount.y + dragAmount.x * 0.5f) / 150f
                        currentNorm = (currentNorm + delta).coerceIn(0f, 1f)
                        onValueChange(minValue + currentNorm * (maxValue - minValue))
                    }
                }
        ) {
            Canvas(modifier = Modifier.size(knobSize)) {
                val strokeW = 4.dp.toPx()
                val arcInset = strokeW / 2f + 2.dp.toPx()
                val arcSize = Size(size.width - arcInset * 2, size.height - arcInset * 2)

                drawArc(
                    color = Color(0xFF232C3B),
                    startAngle = 135f,
                    sweepAngle = 270f,
                    useCenter = false,
                    topLeft = Offset(arcInset, arcInset),
                    size = arcSize,
                    style = Stroke(width = strokeW, cap = StrokeCap.Round)
                )

                drawArc(
                    color = Color(0xFF2299FF),
                    startAngle = 135f,
                    sweepAngle = 270f * normalized,
                    useCenter = false,
                    topLeft = Offset(arcInset, arcInset),
                    size = arcSize,
                    style = Stroke(width = strokeW, cap = StrokeCap.Round)
                )

                val radius = (size.minDimension / 2f) - 8.dp.toPx()
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(Color(0xFF3E4756), Color(0xFF191D24), Color(0xFF0D1015))
                    ),
                    radius = radius
                )

                val angleRad = (135.0 + 270.0 * normalized) * PI / 180.0
                val innerR = radius * 0.25f
                val outerR = radius * 0.82f
                drawLine(
                    color = Color(0xFF7DD3FC),
                    start = Offset(
                        center.x + (cos(angleRad) * innerR).toFloat(),
                        center.y + (sin(angleRad) * innerR).toFloat()
                    ),
                    end = Offset(
                        center.x + (cos(angleRad) * outerR).toFloat(),
                        center.y + (sin(angleRad) * outerR).toFloat()
                    ),
                    strokeWidth = 2.5.dp.toPx(),
                    cap = StrokeCap.Round
                )
            }
        }
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = displayValue,
            color = Color(0xFF7DD3FC),
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}

@Composable
fun HardwareArrowNavButton(
    isPrevious: Boolean,
    contentDescription: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(9.dp)
    Box(
        contentAlignment = Alignment.Center,
        modifier = modifier
            .height(46.dp)
            .shadow(
                elevation = 8.dp,
                shape = shape,
                ambientColor = Color(0xFF0A4DA6),
                spotColor = Color(0xFF1A8CFF)
            )
            .clip(shape)
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF1E2D45),
                        Color(0xFF101928),
                        Color(0xFF0A101B)
                    )
                )
            )
            .border(
                width = 1.8.dp,
                brush = Brush.linearGradient(
                    colors = listOf(
                        Color(0xFF7DD3FC),
                        Color(0xFF1D8BFF),
                        Color(0xFF38BDF8)
                    )
                ),
                shape = shape
            )
            .clickable(onClick = onClick)
    ) {
        Icon(
            imageVector = if (isPrevious) Icons.Default.FastRewind else Icons.Default.FastForward,
            contentDescription = contentDescription,
            tint = Color(0xFFE0F2FE),
            modifier = Modifier.size(28.dp)
        )
    }
}

/**
 * Larger, touch-scrollable Blue LCD Patch List displaying all 500 patches
 * with real LazyColumn finger scrolling, interactive scrollbar scrubbing,
 * Search button, Up/Down arrows, and instant patch selection.
 */
@Composable
fun BlueLcdPatchList(
    patches: List<PatchSlot>,
    activePatchNumber: Int,
    isEditMode: Boolean,
    onSelectPatch: (Int) -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onOpenSearchModal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listState = rememberLazyListState(
        initialFirstVisibleItemIndex = (activePatchNumber - 2).coerceIn(0, (patches.size - 1).coerceAtLeast(0))
    )
    val coroutineScope = rememberCoroutineScope()
    val activePatch = patches.getOrNull(activePatchNumber - 1)

    // Keep active patch visible when Previous/Next/Search updates activePatchNumber
    LaunchedEffect(activePatchNumber) {
        val targetIdx = (activePatchNumber - 1).coerceIn(0, (patches.size - 1).coerceAtLeast(0))
        val visible = listState.layoutInfo.visibleItemsInfo.map { it.index }
        if (targetIdx !in visible) {
            listState.animateScrollToItem((targetIdx - 1).coerceAtLeast(0))
        }
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(10.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(Color(0xFF0B3572), Color(0xFF061B3F))
                )
            )
            .border(2.dp, Color(0xFF38BDF8), RoundedCornerShape(10.dp))
            .padding(10.dp)
    ) {
        // Header Row: Patch List + 001 / 500 + Search (No EDIT button inside Patch List)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 5.dp)
        ) {
            Text(
                text = "Patch List",
                color = Color(0xFFBAE6FD),
                fontSize = 12.5.sp,
                fontWeight = FontWeight.ExtraBold
            )
            Text(
                text = "${activePatchNumber.toString().padStart(3, '0')} / ${patches.size}",
                color = Color(0xFF7DD3FC),
                fontSize = 12.sp,
                fontFamily = FontFamily.Monospace,
                fontWeight = FontWeight.Bold
            )
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(5.dp))
                    .background(Color(0xFF104994))
                    .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.6f), RoundedCornerShape(5.dp))
                    .clickable(onClick = onOpenSearchModal)
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Search,
                    contentDescription = "Search Patches",
                    tint = Color.White,
                    modifier = Modifier.size(12.dp)
                )
                Text(
                    text = "Search",
                    color = Color.White,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // Current Active Patch or Edit Mode Instruction Banner
        if (isEditMode) {
            Text(
                text = "EDIT MODE ACTIVE · Tap any pad 1–8 to customize",
                color = Color(0xFF86EFAC),
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF0A3B2E))
                    .padding(horizontal = 7.dp, vertical = 4.dp)
            )
        } else if (activePatch != null) {
            Text(
                text = "${activePatch.category} · ${activePatch.name}",
                color = Color.White,
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(4.dp))
                    .background(Color(0xFF07224E))
                    .padding(horizontal = 7.dp, vertical = 4.dp)
            )
        }

        Spacer(modifier = Modifier.height(6.dp))

        // Real Finger-Scrollable LazyColumn + Interactive Up/Down/Scrollbar Rail
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .weight(1f)
        ) {
            LazyColumn(
                state = listState,
                verticalArrangement = Arrangement.spacedBy(4.dp),
                modifier = Modifier
                    .weight(1f)
                    .fillMaxHeight()
            ) {
                items(patches, key = { "${it.number}_${it.id}" }) { slot ->
                    val isSelected = slot.number == activePatchNumber
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(32.dp)
                            .clip(RoundedCornerShape(5.dp))
                            .background(if (isSelected) Color(0xFF1D8BFF) else Color(0xFF082552))
                            .border(
                                width = if (isSelected) 1.dp else 0.5.dp,
                                color = if (isSelected) Color(0xFF93C5FD) else Color(0xFF133A75),
                                shape = RoundedCornerShape(5.dp)
                            )
                            .clickable { onSelectPatch(slot.number) }
                            .padding(horizontal = 8.dp)
                    ) {
                        Text(
                            text = slot.number.toString().padStart(3, '0'),
                            color = when {
                                isSelected -> Color.White
                                slot.isImported -> Color(0xFF6EE7B7)
                                else -> Color(0xFF7DD3FC)
                            },
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = slot.name,
                            color = if (isSelected) Color.White else Color(0xFFE0F2FE),
                            fontSize = 12.5.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Right Interactive Up/Down Arrows + Draggable Scrollbar Rail
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween,
                modifier = Modifier
                    .padding(start = 7.dp)
                    .width(26.dp)
                    .fillMaxHeight()
            ) {
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xFF14458A))
                        .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(5.dp))
                        .clickable {
                            coroutineScope.launch {
                                val prev = (listState.firstVisibleItemIndex - 3).coerceAtLeast(0)
                                listState.animateScrollToItem(prev)
                            }
                            onPrevious()
                        }
                ) {
                    Text("▲", color = Color(0xFFE0F2FE), fontSize = 11.sp)
                }

                BoxWithConstraints(
                    modifier = Modifier
                        .width(14.dp)
                        .weight(1f)
                        .padding(vertical = 6.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF04142E))
                        .pointerInput(patches.size) {
                            detectTapGestures { offset ->
                                val ratio = (offset.y / size.height.toFloat()).coerceIn(0f, 1f)
                                val idx = (ratio * (patches.size - 1)).roundToInt()
                                coroutineScope.launch { listState.scrollToItem(idx) }
                            }
                        }
                        .pointerInput(patches.size) {
                            detectVerticalDragGestures { change, _ ->
                                change.consume()
                                val ratio = (change.position.y / size.height.toFloat()).coerceIn(0f, 1f)
                                val idx = (ratio * (patches.size - 1)).roundToInt()
                                coroutineScope.launch { listState.scrollToItem(idx) }
                            }
                        }
                ) {
                    val density = LocalDensity.current
                    val trackPx = with(density) { maxHeight.toPx() }
                    val thumbHeightDp = 28.dp
                    val thumbPx = with(density) { thumbHeightDp.toPx() }
                    val total = (patches.size - 1).coerceAtLeast(1)
                    val ratio = (listState.firstVisibleItemIndex.toFloat() / total).coerceIn(0f, 1f)
                    val offsetPx = ((trackPx - thumbPx) * ratio).roundToInt().coerceAtLeast(0)

                    Box(
                        modifier = Modifier
                            .offset { IntOffset(0, offsetPx) }
                            .width(14.dp)
                            .height(thumbHeightDp)
                            .clip(CircleShape)
                            .background(Color(0xFF38BDF8))
                    )
                }

                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(26.dp)
                        .clip(RoundedCornerShape(5.dp))
                        .background(Color(0xFF14458A))
                        .border(1.dp, Color(0xFF38BDF8).copy(alpha = 0.5f), RoundedCornerShape(5.dp))
                        .clickable {
                            coroutineScope.launch {
                                val next = (listState.firstVisibleItemIndex + 3).coerceAtMost((patches.size - 1).coerceAtLeast(0))
                                listState.animateScrollToItem(next)
                            }
                            onNext()
                        }
                ) {
                    Text("▼", color = Color(0xFFE0F2FE), fontSize = 11.sp)
                }
            }
        }
    }
}
