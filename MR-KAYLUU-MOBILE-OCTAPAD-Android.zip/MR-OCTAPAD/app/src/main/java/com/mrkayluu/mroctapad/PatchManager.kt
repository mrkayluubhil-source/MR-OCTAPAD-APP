package com.mrkayluu.mroctapad

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class PatchManager(private val storageManager: StorageManager) {

    val categories: List<String> = listOf(
        "Indian Drums",
        "Dhol",
        "Dholak",
        "Tabla",
        "Timli",
        "Nagada",
        "Electronic Drums",
        "Acoustic Drums",
        "Rock Drums",
        "Pop Drums",
        "Dance Drums",
        "Bass Drums",
        "Snare Drums",
        "Cymbals",
        "World Percussion"
    )

    data class BundledSampleInfo(val key: String, val label: String)

    val bundledLibrary: List<BundledSampleInfo> = listOf(
        BundledSampleInfo("pad_kick", "Kick Drum"),
        BundledSampleInfo("pad_snare", "Snare Drum"),
        BundledSampleInfo("pad_hihat_closed", "Closed Hi-Hat"),
        BundledSampleInfo("pad_hihat_open", "Open Hi-Hat"),
        BundledSampleInfo("pad_tom_low", "Low Tom"),
        BundledSampleInfo("pad_tom_high", "High Tom"),
        BundledSampleInfo("pad_crash", "Crash Cymbal"),
        BundledSampleInfo("pad_clap", "Hand Clap"),
        BundledSampleInfo("pad_dhol_bass", "Dhol Dagga"),
        BundledSampleInfo("pad_dhol_treble", "Dhol Tilli"),
        BundledSampleInfo("pad_dholak_ge", "Dholak Ge"),
        BundledSampleInfo("pad_dholak_na", "Dholak Na"),
        BundledSampleInfo("pad_tabla_ge", "Tabla Ge"),
        BundledSampleInfo("pad_tabla_na", "Tabla Na"),
        BundledSampleInfo("pad_timli", "Timli"),
        BundledSampleInfo("pad_nagada", "Nagada"),
        BundledSampleInfo("pad_conga", "Conga"),
        BundledSampleInfo("pad_rimshot", "Rimshot")
    )

    private val customOverrides = storageManager.loadCustomPatches().toMutableMap()
    private val importedPatchesList = storageManager.loadImportedPatches().toMutableList()

    private val _patches = MutableStateFlow(buildUnifiedPatches())
    val patches: StateFlow<List<PatchSlot>> = _patches.asStateFlow()

    private val _activePatchNumber = MutableStateFlow(
        storageManager.loadActivePatchNumber().coerceIn(1, _patches.value.size.coerceAtLeast(500))
    )
    val activePatchNumber: StateFlow<Int> = _activePatchNumber.asStateFlow()

    val activePatch: PatchSlot
        get() = _patches.value.getOrElse(_activePatchNumber.value - 1) { _patches.value.first() }

    fun isFactorySlotCustomized(patchNumber: Int): Boolean =
        patchNumber in 1..500 && customOverrides.containsKey(patchNumber)

    fun selectPatch(patchNumber: Int) {
        val maxSlot = _patches.value.size.coerceAtLeast(500)
        val clamped = patchNumber.coerceIn(1, maxSlot)
        _activePatchNumber.value = clamped
        storageManager.saveActivePatchNumber(clamped)
    }

    fun previousPatch() {
        val total = _patches.value.size.coerceAtLeast(500)
        val cur = _activePatchNumber.value
        selectPatch(if (cur <= 1) total else cur - 1)
    }

    fun nextPatch() {
        val total = _patches.value.size.coerceAtLeast(500)
        val cur = _activePatchNumber.value
        selectPatch(if (cur >= total) 1 else cur + 1)
    }

    fun renamePatch(patchNumber: Int, newName: String) {
        val trimmed = newName.trim().take(36)
        if (trimmed.isEmpty()) return
        val current = _patches.value.getOrNull(patchNumber - 1) ?: return
        persistPatchChange(current.copy(name = trimmed))
    }

    fun assignSoundToPad(
        patchNumber: Int,
        padIndex: Int,
        sampleKey: String,
        sampleName: String,
        customSoundId: String?
    ) {
        val current = _patches.value.getOrNull(patchNumber - 1) ?: return
        val newPads = current.pads.map { pad ->
            if (pad.padIndex == padIndex) {
                pad.copy(
                    sampleKey = sampleKey,
                    sampleName = sampleName,
                    customSoundId = customSoundId
                )
            } else pad
        }
        persistPatchChange(current.copy(pads = newPads))
    }

    fun updatePadSettings(
        patchNumber: Int,
        padIndex: Int,
        volume: Float? = null,
        pitch: Float? = null,
        midiNote: Int? = null
    ) {
        val current = _patches.value.getOrNull(patchNumber - 1) ?: return
        val newPads = current.pads.map { pad ->
            if (pad.padIndex == padIndex) {
                pad.copy(
                    volume = (volume ?: pad.volume).coerceIn(0f, 1.4f),
                    pitch = (pitch ?: pad.pitch).coerceIn(0.5f, 2.0f),
                    midiNote = (midiNote ?: pad.midiNote).coerceIn(0, 127)
                )
            } else pad
        }
        persistPatchChange(current.copy(pads = newPads))
    }

    fun saveEditedPatch(
        patchNumber: Int,
        name: String,
        category: String,
        pads: List<PadConfig>
    ) {
        val maxSlot = _patches.value.size.coerceAtLeast(500)
        val cleanNum = patchNumber.coerceIn(1, maxSlot)
        val current = _patches.value.getOrNull(cleanNum - 1) ?: return
        val cleanName = name.trim().take(36).ifEmpty { current.name }
        val cleanCat = category.trim().ifEmpty { current.category }
        val updated = current.copy(
            number = cleanNum,
            name = cleanName,
            category = cleanCat,
            pads = pads.mapIndexed { idx, pad -> pad.copy(padIndex = idx) }
        )
        persistPatchChange(updated)
    }

    fun saveAsNewPatch(
        targetPatchNumber: Int,
        name: String,
        category: String,
        pads: List<PadConfig>
    ): Int {
        val maxSlot = _patches.value.size.coerceAtLeast(500)
        val target = targetPatchNumber.coerceIn(1, maxSlot)
        saveEditedPatch(target, name, category, pads)
        selectPatch(target)
        return target
    }

    fun savePadConfig(patchNumber: Int, padConfig: PadConfig) {
        val maxSlot = _patches.value.size.coerceAtLeast(500)
        val cleanNum = patchNumber.coerceIn(1, maxSlot)
        val current = _patches.value.getOrNull(cleanNum - 1) ?: return
        val idx = padConfig.padIndex.coerceIn(0, 7)
        val cleanPad = padConfig.copy(
            padIndex = idx,
            volume = padConfig.volume.coerceIn(0f, 1.4f),
            pitch = padConfig.pitch.coerceIn(0.5f, 2.0f),
            midiNote = padConfig.midiNote.coerceIn(0, 127)
        )
        val newPads = current.pads.map { p -> if (p.padIndex == idx) cleanPad else p }
        persistPatchChange(current.copy(pads = newPads))
    }

    fun getDefaultPadConfig(patchNumber: Int, padIndex: Int): PadConfig {
        val cleanNum = patchNumber.coerceIn(1, 500)
        val idx = padIndex.coerceIn(0, 7)
        return generateDefaultPatch(cleanNum).pads[idx]
    }

    fun applyPadsToActivePatch(pads: List<PadConfig>) {
        val current = activePatch
        persistPatchChange(current.copy(pads = pads))
    }

    fun importPatchesCollection(
        incoming: List<PatchSlot>,
        selectFirstImported: Boolean = true
    ): List<PatchSlot> {
        if (incoming.isEmpty()) return emptyList()
        val existingNames = _patches.value.map { it.name.lowercase() }.toMutableSet()
        val added = ArrayList<PatchSlot>(incoming.size)
        var nextNumber = 500 + importedPatchesList.size + 1

        incoming.forEach { raw ->
            var candidateName = raw.name.trim().take(32).ifEmpty { "Imported Patch" }
            if (existingNames.contains(candidateName.lowercase())) {
                var suffix = 2
                while (existingNames.contains("$candidateName ($suffix)".lowercase())) {
                    suffix++
                }
                candidateName = "$candidateName ($suffix)".take(36)
            }
            existingNames.add(candidateName.lowercase())

            val slot = raw.copy(
                number = nextNumber,
                name = candidateName,
                category = raw.category.trim().ifEmpty { "Imported Phone" },
                pads = raw.pads.take(8).mapIndexed { idx, p -> p.copy(padIndex = idx) },
                isImported = true,
                importedAtMs = if (raw.importedAtMs > 0L) raw.importedAtMs else System.currentTimeMillis()
            )
            importedPatchesList.add(slot)
            added.add(slot)
            nextNumber++
        }

        storageManager.saveImportedPatches(importedPatchesList)
        _patches.value = buildUnifiedPatches()
        if (selectFirstImported && added.isNotEmpty()) {
            selectPatch(added.first().number)
        }
        return added
    }

    fun deleteImportedPatch(patchNumber: Int): Boolean {
        val importedIdx = patchNumber - 501
        if (importedIdx !in importedPatchesList.indices) return false
        importedPatchesList.removeAt(importedIdx)
        val renumbered = importedPatchesList.mapIndexed { idx, p -> p.copy(number = 501 + idx) }
        importedPatchesList.clear()
        importedPatchesList.addAll(renumbered)
        storageManager.saveImportedPatches(importedPatchesList)
        _patches.value = buildUnifiedPatches()
        if (_activePatchNumber.value == patchNumber) {
            selectPatch((patchNumber - 1).coerceIn(1, _patches.value.size))
        } else if (_activePatchNumber.value > patchNumber) {
            selectPatch((_activePatchNumber.value - 1).coerceIn(1, _patches.value.size))
        }
        return true
    }

    fun resetPatchToDefault(patchNumber: Int) {
        if (patchNumber !in 1..500) return
        customOverrides.remove(patchNumber)
        storageManager.saveCustomPatches(customOverrides)
        _patches.value = buildUnifiedPatches()
    }

    fun searchPatches(query: String): List<PatchSlot> {
        val q = query.trim().lowercase()
        if (q.isEmpty()) return _patches.value
        return _patches.value.filter { patch ->
            patch.name.lowercase().contains(q) ||
                patch.category.lowercase().contains(q) ||
                (patch.sourcePackName?.lowercase()?.contains(q) == true) ||
                patch.number.toString().padStart(3, '0').contains(q)
        }
    }

    private fun persistPatchChange(updated: PatchSlot) {
        if (updated.number > 500 || updated.isImported) {
            val impIdx = updated.number - 501
            if (impIdx in importedPatchesList.indices) {
                importedPatchesList[impIdx] = updated.copy(isImported = true)
                storageManager.saveImportedPatches(importedPatchesList)
                _patches.value = _patches.value.toMutableList().also { list ->
                    if (updated.number - 1 in list.indices) {
                        list[updated.number - 1] = importedPatchesList[impIdx]
                    }
                }
            }
            return
        }
        customOverrides[updated.number] = updated
        storageManager.saveCustomPatches(customOverrides)
        _patches.value = _patches.value.toMutableList().also { list ->
            list[updated.number - 1] = updated
        }
    }

    private fun buildUnifiedPatches(): List<PatchSlot> {
        val result = ArrayList<PatchSlot>(500 + importedPatchesList.size)
        for (num in 1..500) {
            val override = customOverrides[num]
            if (override != null) {
                result.add(override)
            } else {
                result.add(generateDefaultPatch(num))
            }
        }
        importedPatchesList.forEachIndexed { idx, patch ->
            result.add(patch.copy(number = 501 + idx, isImported = true))
        }
        return result
    }

    private fun generateDefaultPatch(number: Int): PatchSlot {
        val categoryIndex = ((number - 1) * categories.size) / 500
        val category = categories[categoryIndex.coerceIn(0, categories.lastIndex)]
        val variantIndex = ((number - 1) % 34) + 1
        val styleNames = when (category) {
            "Indian Drums" -> listOf("Garba Fusion", "Bhajan Groove", "Desi Stage", "Folk Ensemble", "Festival Beat")
            "Dhol" -> listOf("Punjabi Dhol", "Bhangra Power", "Dhol Tasha", "Wedding Dhol", "Street Dhol")
            "Dholak" -> listOf("Qawwali Dholak", "Kirtan Dholak", "Mehfil Thap", "Lok Geet", "Studio Dholak")
            "Tabla" -> listOf("Teental Classical", "Keherwa Folk", "Dadra Acoustic", "Tabla Tarang", "Concert Tabla")
            "Timli" -> listOf("Gujarati Timli", "Dakla Timli", "Navratri Mix", "Tribal Timli", "Fast Timli")
            "Nagada" -> listOf("Rajasthani Nagada", "Temple Nagada", "Royal Procession", "Shahi Nagada", "Deep Nagada")
            "Electronic Drums" -> listOf("Electro 808", "Synth Percussion", "Cyber Kit", "Analog Pulse", "Club Matrix")
            "Acoustic Drums" -> listOf("Studio Maple", "Warm Birch", "Live Stage", "Dry Room", "Jazz Brush")
            "Rock Drums" -> listOf("Arena Rock", "Heavy Punch", "Classic 70s", "Hard Drive", "Stadium Kit")
            "Pop Drums" -> listOf("Top 40 Pop", "Crisp Modern", "Radio Hit", "Tight Funk", "Indie Pop")
            "Dance Drums" -> listOf("EDM Drop", "House Groove", "DJ Bolly", "Trance Kick", "Festival Club")
            "Bass Drums" -> listOf("Sub Punch", "Deep Thump", "808 Boom", "Tight Low", "Double Kick")
            "Snare Drums" -> listOf("Crack Snare", "Piccolo Snap", "Brass Shell", "Rim Groove", "Gated Snare")
            "Cymbals" -> listOf("Bright Crash", "Splash & Hat", "Ride Shimmer", "Dark Bronze", "Accent Brass")
            else -> listOf("Afro Latin", "Conga Bongo", "Tribal Fusion", "Global Percussion", "Carnival")
        }
        val baseTitle = styleNames[(variantIndex - 1) % styleNames.size]
        val patchName = "$baseTitle ${variantIndex.toString().padStart(2, '0')}"

        val padSamples = defaultSamplesForCategory(category, variantIndex)
        val pitchShift = 0.92f + ((variantIndex % 5) * 0.04f)
        val defaultNotes = listOf(36, 38, 42, 46, 45, 48, 49, 39)

        val pads = (0 until 8).map { idx ->
            val (key, label) = padSamples[idx]
            PadConfig(
                padIndex = idx,
                sampleKey = key,
                sampleName = label,
                volume = 0.9f,
                pitch = pitchShift,
                midiNote = defaultNotes[idx],
                customSoundId = null
            )
        }

        return PatchSlot(number = number, name = patchName, category = category, pads = pads)
    }

    private fun defaultSamplesForCategory(category: String, variant: Int): List<Pair<String, String>> {
        return when (category) {
            "Indian Drums" -> listOf(
                "pad_dhol_bass" to "Dhol Dagga",
                "pad_dhol_treble" to "Dhol Tilli",
                "pad_tabla_ge" to "Tabla Ge",
                "pad_tabla_na" to "Tabla Na",
                "pad_dholak_ge" to "Dholak Ge",
                "pad_dholak_na" to "Dholak Na",
                "pad_timli" to "Timli",
                "pad_nagada" to "Nagada"
            )
            "Dhol" -> listOf(
                "pad_dhol_bass" to "Dhol Dagga",
                "pad_dhol_treble" to "Dhol Tilli",
                "pad_kick" to "Sub Kick",
                "pad_timli" to "Timli Accent",
                "pad_nagada" to "Nagada",
                "pad_dholak_na" to "Chanti",
                "pad_clap" to "Clap",
                "pad_crash" to "Crash"
            )
            "Dholak" -> listOf(
                "pad_dholak_ge" to "Dholak Ge",
                "pad_dholak_na" to "Dholak Na",
                "pad_tabla_ge" to "Bayan Ge",
                "pad_tabla_na" to "Dayan Na",
                "pad_rimshot" to "Wood Rim",
                "pad_hihat_closed" to "Manjira",
                "pad_conga" to "Thap",
                "pad_clap" to "Taali"
            )
            "Tabla" -> listOf(
                "pad_tabla_ge" to "Tabla Ge",
                "pad_tabla_na" to "Tabla Na",
                "pad_dholak_ge" to "Dholak Ge",
                "pad_dholak_na" to "Dholak Na",
                "pad_timli" to "Teen",
                "pad_rimshot" to "Na Stroke",
                "pad_hihat_closed" to "Chime",
                "pad_crash" to "Jhanjh"
            )
            "Timli" -> listOf(
                "pad_timli" to "Timli High",
                "pad_dhol_treble" to "Tilli",
                "pad_dhol_bass" to "Dhol Bass",
                "pad_nagada" to "Nagada",
                "pad_clap" to "Folk Clap",
                "pad_snare" to "Roll Snare",
                "pad_hihat_closed" to "Closed Hat",
                "pad_hihat_open" to "Open Hat"
            )
            "Nagada" -> listOf(
                "pad_nagada" to "Nagada Deep",
                "pad_dhol_bass" to "Big Dhol",
                "pad_timli" to "Timli",
                "pad_dhol_treble" to "Dhol Tilli",
                "pad_tom_low" to "Low Kettle",
                "pad_tom_high" to "High Kettle",
                "pad_crash" to "Jhanjh Crash",
                "pad_rimshot" to "Stick Click"
            )
            "Dance Drums", "Electronic Drums" -> listOf(
                "pad_kick" to "Electro Kick",
                "pad_snare" to "Electro Snare",
                "pad_hihat_closed" to "Closed Hat",
                "pad_hihat_open" to "Open Hat",
                "pad_clap" to "Dance Clap",
                "pad_tom_low" to "Synth Tom L",
                "pad_tom_high" to "Synth Tom H",
                "pad_crash" to "Crash"
            )
            "Cymbals" -> listOf(
                "pad_crash" to "Crash 1",
                "pad_hihat_open" to "Open Hat",
                "pad_hihat_closed" to "Closed Hat",
                "pad_crash" to "Crash 2",
                "pad_kick" to "Kick",
                "pad_snare" to "Snare",
                "pad_rimshot" to "Bell Ping",
                "pad_clap" to "Clap"
            )
            "Bass Drums" -> listOf(
                "pad_kick" to "Main Kick",
                "pad_dhol_bass" to "Sub Bass",
                "pad_tom_low" to "Low Punch",
                "pad_nagada" to "Boom",
                "pad_snare" to "Snare",
                "pad_hihat_closed" to "Closed Hat",
                "pad_clap" to "Clap",
                "pad_crash" to "Crash"
            )
            "Snare Drums" -> listOf(
                "pad_snare" to "Main Snare",
                "pad_rimshot" to "Rimshot",
                "pad_clap" to "Snap Clap",
                "pad_dhol_treble" to "Tight Skin",
                "pad_kick" to "Kick",
                "pad_hihat_closed" to "Closed Hat",
                "pad_hihat_open" to "Open Hat",
                "pad_crash" to "Crash"
            )
            "World Percussion" -> listOf(
                "pad_conga" to "Conga Slap",
                "pad_dholak_ge" to "Bongo Low",
                "pad_dholak_na" to "Bongo High",
                "pad_tabla_na" to "Bell Tone",
                "pad_timli" to "Clave/Timli",
                "pad_rimshot" to "Woodblock",
                "pad_hihat_closed" to "Shaker",
                "pad_crash" to "Gong/Crash"
            )
            else -> {
                val kickKey = if (variant % 2 == 0) "pad_kick" else "pad_tom_low"
                listOf(
                    kickKey to "Kick",
                    "pad_snare" to "Snare",
                    "pad_hihat_closed" to "Closed Hat",
                    "pad_hihat_open" to "Open Hat",
                    "pad_tom_low" to "Floor Tom",
                    "pad_tom_high" to "Rack Tom",
                    "pad_crash" to "Crash Cymbal",
                    "pad_clap" to "Clap"
                )
            }
        }
    }
}
