package com.mrkayluu.mroctapad

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

enum class ActivePanel {
    NONE, PATCH_LOAD, MIDI, EFFECTS, PAD_EDITOR, PATCH_EDITOR, STUDIO_LIBRARY
}

/**
 * Glossy black right-side hardware control panel:
 * - OCTAPAD / MR KAYLUU header
 * - Strictly 4 top buttons in order: PATCH LOAD | MIDI | EDIT | EFFECTS
 * - Larger touch-scrollable Blue LCD Patch List (NO separate EDIT button inside Patch List)
 * - Previous & Next buttons (or DONE button in Pad Edit Mode)
 * - NO rotary effect knobs on the main screen (effects live inside EFFECTS panel)
 */
@Composable
fun ControlPanel(
    patches: List<PatchSlot>,
    activePatchNumber: Int,
    activePanel: ActivePanel,
    isEditMode: Boolean,
    onToggleEditMode: () -> Unit,
    onOpenPanel: (ActivePanel) -> Unit,
    onSelectPatch: (Int) -> Unit,
    onPreviousPatch: () -> Unit,
    onNextPatch: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        verticalArrangement = Arrangement.spacedBy(12.dp),
        modifier = modifier
            .fillMaxHeight()
            .shadow(12.dp, RoundedCornerShape(14.dp))
            .clip(RoundedCornerShape(14.dp))
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        Color(0xFF161C27),
                        Color(0xFF0A0D13),
                        Color(0xFF05070B)
                    )
                )
            )
            .border(1.5.dp, Color(0xFF2E384A), RoundedCornerShape(14.dp))
            .padding(horizontal = 14.dp, vertical = 12.dp)
    ) {
        // 1. Hardware Header: OCTAPAD + MR KAYLUU
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "OCTAPAD",
                color = Color(0xFFF8FAFC),
                fontSize = 21.sp,
                fontWeight = FontWeight.ExtraBold,
                letterSpacing = 1.8.sp
            )
            Text(
                text = "MR KAYLUU",
                color = Color(0xFF60A5FA),
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.1.sp
            )
        }

        // 2. Strictly 4 top buttons: PATCH LOAD | MIDI | EDIT | EFFECTS
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            modifier = Modifier.fillMaxWidth()
        ) {
            HardwareFunctionButton(
                label = "PATCH LOAD",
                isActive = activePanel == ActivePanel.PATCH_LOAD,
                onClick = { onOpenPanel(ActivePanel.PATCH_LOAD) },
                modifier = Modifier.weight(1.15f)
            )
            HardwareFunctionButton(
                label = "MIDI",
                isActive = activePanel == ActivePanel.MIDI,
                onClick = { onOpenPanel(ActivePanel.MIDI) },
                modifier = Modifier.weight(0.92f)
            )
            HardwareFunctionButton(
                label = "EDIT",
                isActive = isEditMode,
                onClick = onToggleEditMode,
                modifier = Modifier.weight(0.92f)
            )
            HardwareFunctionButton(
                label = "EFFECTS",
                isActive = activePanel == ActivePanel.EFFECTS,
                onClick = { onOpenPanel(ActivePanel.EFFECTS) },
                modifier = Modifier.weight(1.01f)
            )
        }

        // 3. Larger Touch-Scrollable Blue LCD Patch List (no separate EDIT button inside display)
        BlueLcdPatchList(
            patches = patches,
            activePatchNumber = activePatchNumber,
            isEditMode = isEditMode,
            onSelectPatch = onSelectPatch,
            onPrevious = onPreviousPatch,
            onNext = onNextPatch,
            onOpenSearchModal = { onOpenPanel(ActivePanel.PATCH_LOAD) },
            modifier = Modifier.weight(1f)
        )

        // 4. Large blue-glowing arrow icon buttons (or clear DONE button when Pad Edit Mode is active)
        if (isEditMode) {
            Button(
                onClick = onToggleEditMode,
                shape = RoundedCornerShape(7.dp),
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFF16A34A),
                    contentColor = Color.White
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF86EFAC), RoundedCornerShape(7.dp))
            ) {
                Text(
                    text = "DONE — EXIT EDIT MODE",
                    fontSize = 12.5.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        } else {
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                HardwareArrowNavButton(
                    isPrevious = true,
                    contentDescription = "Previous Patch",
                    onClick = onPreviousPatch,
                    modifier = Modifier.weight(1f)
                )
                HardwareArrowNavButton(
                    isPrevious = false,
                    contentDescription = "Next Patch",
                    onClick = onNextPatch,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}
