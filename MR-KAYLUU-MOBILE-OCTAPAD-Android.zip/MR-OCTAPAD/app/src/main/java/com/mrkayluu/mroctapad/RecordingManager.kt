package com.mrkayluu.mroctapad

import android.os.SystemClock
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.UUID

enum class PlaybackState { STOPPED, PLAYING, PAUSED }

data class RecorderState(
    val isRecording: Boolean = false,
    val recordedEventCount: Int = 0,
    val recordingElapsedMs: Long = 0L,
    val playbackState: PlaybackState = PlaybackState.STOPPED,
    val playingRecordingId: String? = null,
    val isLooping: Boolean = true,
    val hasUnsavedRecording: Boolean = false
)

class RecordingManager(
    private val storageManager: StorageManager,
    private val patchManager: PatchManager,
    private val onReplayEvent: (padIndex: Int, velocity: Float, sampleKey: String, customSoundId: String?, midiNote: Int) -> Unit
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    private val _recordings = MutableStateFlow(storageManager.loadRecordings())
    val recordings: StateFlow<List<PerformanceRecording>> = _recordings.asStateFlow()

    private val _state = MutableStateFlow(RecorderState())
    val state: StateFlow<RecorderState> = _state.asStateFlow()

    private var recordStartTimeMs = 0L
    private var recordPatchNumber = 1
    private val capturedEvents = mutableListOf<RecordedEvent>()
    private var lastCapturedDurationMs = 0L

    private var playbackJob: Job? = null
    private var pausedEventIndex = 0
    private var pausedElapsedMs = 0L

    fun startRecording() {
        stopPlayback()
        capturedEvents.clear()
        recordStartTimeMs = SystemClock.elapsedRealtime()
        recordPatchNumber = patchManager.activePatchNumber.value
        lastCapturedDurationMs = 0L
        _state.value = _state.value.copy(
            isRecording = true,
            recordedEventCount = 0,
            recordingElapsedMs = 0L,
            hasUnsavedRecording = false
        )
    }

    fun stopRecording() {
        if (!_state.value.isRecording) return
        val endElapsed = (SystemClock.elapsedRealtime() - recordStartTimeMs).coerceAtLeast(250L)
        lastCapturedDurationMs = endElapsed
        _state.value = _state.value.copy(
            isRecording = false,
            recordingElapsedMs = endElapsed,
            hasUnsavedRecording = capturedEvents.isNotEmpty()
        )
    }

    fun recordHit(pad: PadConfig, velocity: Float) {
        if (!_state.value.isRecording) return
        val offset = SystemClock.elapsedRealtime() - recordStartTimeMs
        synchronized(capturedEvents) {
            capturedEvents.add(
                RecordedEvent(
                    timestampMs = offset,
                    padIndex = pad.padIndex,
                    velocity = velocity,
                    sampleKey = pad.sampleKey,
                    customSoundId = pad.customSoundId,
                    midiNote = pad.midiNote
                )
            )
        }
        _state.value = _state.value.copy(
            recordedEventCount = capturedEvents.size,
            recordingElapsedMs = offset
        )
    }

    fun saveCurrentRecording(name: String): PerformanceRecording? {
        if (capturedEvents.isEmpty()) return null
        val cleanName = name.trim().ifEmpty { "Take ${_recordings.value.size + 1}" }.take(36)
        val entry = PerformanceRecording(
            id = "rec_${UUID.randomUUID().toString().take(8)}",
            name = cleanName,
            createdAtMs = System.currentTimeMillis(),
            durationMs = lastCapturedDurationMs.coerceAtLeast(capturedEvents.last().timestampMs + 200L),
            patchNumber = recordPatchNumber,
            events = capturedEvents.toList()
        )
        val next = listOf(entry) + _recordings.value
        _recordings.value = next
        storageManager.saveRecordings(next)
        _state.value = _state.value.copy(hasUnsavedRecording = false)
        return entry
    }

    fun playRecording(recordingId: String) {
        val target = _recordings.value.firstOrNull { it.id == recordingId } ?: return
        stopPlayback()
        pausedEventIndex = 0
        pausedElapsedMs = 0L
        startPlaybackLoop(target, startIndex = 0, startOffsetMs = 0L)
    }

    fun pausePlayback() {
        if (_state.value.playbackState != PlaybackState.PLAYING) return
        playbackJob?.cancel()
        playbackJob = null
        _state.value = _state.value.copy(playbackState = PlaybackState.PAUSED)
    }

    fun resumePlayback() {
        val id = _state.value.playingRecordingId ?: return
        if (_state.value.playbackState != PlaybackState.PAUSED) return
        val target = _recordings.value.firstOrNull { it.id == id } ?: return
        startPlaybackLoop(target, startIndex = pausedEventIndex, startOffsetMs = pausedElapsedMs)
    }

    fun stopPlayback() {
        playbackJob?.cancel()
        playbackJob = null
        pausedEventIndex = 0
        pausedElapsedMs = 0L
        _state.value = _state.value.copy(
            playbackState = PlaybackState.STOPPED,
            playingRecordingId = null
        )
    }

    fun toggleLoop() {
        _state.value = _state.value.copy(isLooping = !_state.value.isLooping)
    }

    fun renameRecording(id: String, newName: String) {
        val clean = newName.trim().take(36)
        if (clean.isEmpty()) return
        val next = _recordings.value.map { if (it.id == id) it.copy(name = clean) else it }
        _recordings.value = next
        storageManager.saveRecordings(next)
    }

    fun deleteRecording(id: String) {
        if (_state.value.playingRecordingId == id) stopPlayback()
        val next = _recordings.value.filterNot { it.id == id }
        _recordings.value = next
        storageManager.saveRecordings(next)
    }

    private fun startPlaybackLoop(
        recording: PerformanceRecording,
        startIndex: Int,
        startOffsetMs: Long
    ) {
        _state.value = _state.value.copy(
            playbackState = PlaybackState.PLAYING,
            playingRecordingId = recording.id
        )
        playbackJob = scope.launch {
            var idx = startIndex
            var baseOffset = startOffsetMs
            do {
                val loopWallStart = SystemClock.elapsedRealtime() - baseOffset
                while (isActive && idx < recording.events.size) {
                    val ev = recording.events[idx]
                    val elapsed = SystemClock.elapsedRealtime() - loopWallStart
                    val waitMs = ev.timestampMs - elapsed
                    if (waitMs > 0) {
                        delay(waitMs)
                    }
                    if (!isActive) break
                    pausedEventIndex = idx + 1
                    pausedElapsedMs = ev.timestampMs
                    onReplayEvent(ev.padIndex, ev.velocity, ev.sampleKey, ev.customSoundId, ev.midiNote)
                    idx++
                }
                val remaining = recording.durationMs - (SystemClock.elapsedRealtime() - loopWallStart)
                if (remaining > 0 && isActive) delay(remaining)
                idx = 0
                baseOffset = 0L
                pausedEventIndex = 0
                pausedElapsedMs = 0L
            } while (isActive && _state.value.isLooping)

            if (isActive) {
                _state.value = _state.value.copy(
                    playbackState = PlaybackState.STOPPED,
                    playingRecordingId = null
                )
            }
        }
    }

    fun release() {
        stopPlayback()
    }
}
