package com.mrkayluu.mroctapad

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlin.math.PI
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.sin
import kotlin.math.sqrt

class EqualizerManager(private val storageManager: StorageManager) {

    private val _settings = MutableStateFlow(storageManager.loadEq())
    val settings: StateFlow<EqSettings> = _settings.asStateFlow()

    private class BiquadBand {
        var b0 = 1f; var b1 = 0f; var b2 = 0f
        var a1 = 0f; var a2 = 0f
        var x1 = 0f; var x2 = 0f
        var y1 = 0f; var y2 = 0f

        fun process(input: Float): Float {
            val out = b0 * input + b1 * x1 + b2 * x2 - a1 * y1 - a2 * y2
            x2 = x1; x1 = input
            y2 = y1; y1 = out
            return out
        }
    }

    private val bassBand = BiquadBand()
    private val midBand = BiquadBand()
    private val trebleBand = BiquadBand()

    @Volatile
    private var dirty = true

    @Volatile
    private var lastSampleRate = 44100

    fun updateEq(transform: (EqSettings) -> EqSettings) {
        val next = transform(_settings.value)
        _settings.value = EqSettings(
            enabled = next.enabled,
            bassFreqHz = next.bassFreqHz.coerceIn(50f, 300f),
            bassGainDb = next.bassGainDb.coerceIn(-12f, 12f),
            midFreqHz = next.midFreqHz.coerceIn(350f, 4500f),
            midGainDb = next.midGainDb.coerceIn(-12f, 12f),
            trebleFreqHz = next.trebleFreqHz.coerceIn(4500f, 14000f),
            trebleGainDb = next.trebleGainDb.coerceIn(-12f, 12f)
        )
        dirty = true
    }

    fun saveEq() {
        storageManager.saveEq(_settings.value)
    }

    fun resetEq() {
        _settings.value = EqSettings()
        dirty = true
        saveEq()
    }

    fun processMonoBuffer(buffer: FloatArray, frameCount: Int, sampleRate: Int) {
        val eq = _settings.value
        if (!eq.enabled) return

        if (dirty || sampleRate != lastSampleRate) {
            lastSampleRate = sampleRate
            recomputeBands(eq, sampleRate)
            dirty = false
        }

        val useBass = eq.bassGainDb != 0f
        val useMid = eq.midGainDb != 0f
        val useTreble = eq.trebleGainDb != 0f
        if (!useBass && !useMid && !useTreble) return

        for (i in 0 until frameCount) {
            var s = buffer[i]
            if (useBass) s = bassBand.process(s)
            if (useMid) s = midBand.process(s)
            if (useTreble) s = trebleBand.process(s)
            buffer[i] = s
        }
    }

    private fun recomputeBands(eq: EqSettings, sampleRate: Int) {
        computeLowShelf(bassBand, eq.bassFreqHz, eq.bassGainDb, sampleRate)
        computePeaking(midBand, eq.midFreqHz, eq.midGainDb, 1.15f, sampleRate)
        computeHighShelf(trebleBand, eq.trebleFreqHz, eq.trebleGainDb, sampleRate)
    }

    private fun computeLowShelf(b: BiquadBand, freq: Float, gainDb: Float, sr: Int) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freq / sr
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.85 - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
        val a0 = (a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha
        b.b0 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
        b.b1 = ((2.0 * a * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
        b.b2 = ((a * ((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
        b.a1 = ((-2.0 * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
        b.a2 = (((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
    }

    private fun computePeaking(b: BiquadBand, freq: Float, gainDb: Float, q: Float, sr: Int) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freq / sr
        val cosW0 = cos(w0)
        val alpha = sin(w0) / (2.0 * q)
        val a0 = 1.0 + alpha / a
        b.b0 = ((1.0 + alpha * a) / a0).toFloat()
        b.b1 = ((-2.0 * cosW0) / a0).toFloat()
        b.b2 = ((1.0 - alpha * a) / a0).toFloat()
        b.a1 = ((-2.0 * cosW0) / a0).toFloat()
        b.a2 = ((1.0 - alpha / a) / a0).toFloat()
    }

    private fun computeHighShelf(b: BiquadBand, freq: Float, gainDb: Float, sr: Int) {
        val a = 10.0.pow(gainDb / 40.0)
        val w0 = 2.0 * PI * freq / sr
        val cosW0 = cos(w0)
        val sinW0 = sin(w0)
        val alpha = sinW0 / 2.0 * sqrt((a + 1.0 / a) * (1.0 / 0.85 - 1.0) + 2.0)
        val twoSqrtAAlpha = 2.0 * sqrt(a) * alpha
        val a0 = (a + 1.0) - (a - 1.0) * cosW0 + twoSqrtAAlpha
        b.b0 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 + twoSqrtAAlpha)) / a0).toFloat()
        b.b1 = ((-2.0 * a * ((a - 1.0) + (a + 1.0) * cosW0)) / a0).toFloat()
        b.b2 = ((a * ((a + 1.0) + (a - 1.0) * cosW0 - twoSqrtAAlpha)) / a0).toFloat()
        b.a1 = ((2.0 * ((a - 1.0) - (a + 1.0) * cosW0)) / a0).toFloat()
        b.a2 = (((a + 1.0) - (a - 1.0) * cosW0 - twoSqrtAAlpha) / a0).toFloat()
    }
}
