# MR KAYLUU MOBILE OCTAPAD — ProGuard Rules
-keep class com.mrkayluu.mroctapad.** { *; }
